class Main {

  public static void main(String [] args){

    WeatherTester t = new WeatherTester();

    t.testWeather();
  }
}